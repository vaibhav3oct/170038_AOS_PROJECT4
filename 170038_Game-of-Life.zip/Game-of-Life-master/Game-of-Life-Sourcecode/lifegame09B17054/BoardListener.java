package lifegame09B17054;

public interface BoardListener {
	
	public void updated(BoardModel m);
	
}
